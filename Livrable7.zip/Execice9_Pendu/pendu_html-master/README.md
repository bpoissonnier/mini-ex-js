# pendu_html
 
 Jeu du pendu en html et javascript

## Jouer

 [Lien du pendu](https://nath54.github.io/pendu_html/index.html)

 N'hésitez pas à mettre une étoile si vous avez bien aimé le jeu ;)
