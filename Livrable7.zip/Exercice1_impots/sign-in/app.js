var p = document.querySelector('p')
var rougit = function(){
    p.classList.toggle('red')
}
p.addEventListener('click',rougit)